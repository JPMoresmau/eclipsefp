(make clean; make HC=ghc-6.10.4 PKG=ghc-pkg-6.10.4) &&
(make clean; make HC=ghc-6.12.1 PKG=ghc-pkg-6.12.1)
