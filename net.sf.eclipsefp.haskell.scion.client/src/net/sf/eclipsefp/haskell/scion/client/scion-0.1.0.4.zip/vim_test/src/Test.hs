module Test where

test = print "success"
